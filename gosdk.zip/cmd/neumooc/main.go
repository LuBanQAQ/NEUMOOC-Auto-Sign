// Command neumooc 是东软智慧教育 App 的 Go 命令行客户端。
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"strings"

	"neumooc"
)

func main() {
	if len(os.Args) < 2 {
		usage()
		os.Exit(1)
	}
	cmd, args := os.Args[1], os.Args[2:]
	switch cmd {
	case "login":
		cmdLogin(args)
	case "auto-checkin":
		cmdAutoCheckin(args)
	case "profile":
		cmdProfile(args)
	case "refresh":
		cmdRefresh(args)
	case "call":
		cmdCall(args)
	default:
		usage()
		os.Exit(1)
	}
}

func usage() {
	fmt.Println(`用法：
  neumooc login -u 学号 -p 密码 -t 租户ID [--save-credentials] [--website 域名] [--debug]
  neumooc auto-checkin [--interval 30] [--once] [--dry-run] [--qr-sign-type 0|1] ...
  neumooc profile
  neumooc refresh
  neumooc call METHOD PATH [--params '{"id":1}'] [--body '...']`)
}

func cmdLogin(args []string) {
	fs := flag.NewFlagSet("login", flag.ExitOnError)
	username := fs.String("u", "", "学号/账号")
	password := fs.String("p", "", "登录密码（不填则交互输入）")
	tenant := fs.String("t", "", "租户/学校 ID")
	website := fs.String("website", "", "覆盖业务域名")
	debug := fs.Bool("debug", false, "打印原始请求/响应")
	insecure := fs.Bool("insecure", false, "忽略 TLS 证书校验")
	saveCred := fs.Bool("save-credentials", false, "保存账号密码用于令牌失效后自动重登")
	fs.Parse(args)

	if *username == "" {
		fmt.Fprintln(os.Stderr, "请提供 -u 学号")
		os.Exit(1)
	}
	if *password == "" {
		fmt.Print("登录密码：")
		_, _ = fmt.Scanln(password)
	}
	if *password == "" {
		fmt.Fprintln(os.Stderr, "未输入密码")
		os.Exit(1)
	}

	client := neumooc.NewClient(*website, *debug, *insecure)
	if _, err := client.LoginWithPassword(*username, *password, *tenant); err != nil {
		fmt.Fprintf(os.Stderr, "登录失败：%v\n", err)
		os.Exit(1)
	}
	fmt.Println("[OK] 登录成功（AUTH-02）")
	if *saveCred {
		_ = client.SaveCredentials(*username, *password)
	}
	printSession(client)
}

func cmdAutoCheckin(args []string) {
	fs := flag.NewFlagSet("auto-checkin", flag.ExitOnError)
	interval := fs.Int("interval", 30, "轮询间隔秒数（最小 5）")
	once := fs.Bool("once", false, "只扫描一轮即退出")
	maxRounds := fs.Int("max-rounds", 0, "最多轮询轮数（0 不限）")
	termID := fs.String("term-id", "", "学期 ID（默认自动识别）")
	courseID := fs.String("course-id", "", "只关注指定课程")
	longitude := fs.String("longitude", "", "定位签到经度（缺省默认学校坐标）")
	latitude := fs.String("latitude", "", "定位签到纬度（缺省默认学校坐标）")
	address := fs.String("address", "", "定位签到地址")
	qrSignType := fs.Int("qr-sign-type", neumooc.QRBypassSignType, "二维码考勤直签的 type 值（默认 1）")
	includeTeacher := fs.Bool("include-teacher", false, "教师考勤也尝试签到")
	anyStatus := fs.Bool("any-status", false, "不过滤考勤状态")
	dryRun := fs.Bool("dry-run", false, "只打印提交体，不实际提交")
	maxAttempts := fs.Int("max-attempts", 3, "每场考勤失败重试上限")
	quiet := fs.Bool("quiet", false, "无考勤数据的轮次不打印日志")
	pageSize := fs.Int("page-size", 0, "ATT-01 分页大小（0 用服务端默认）")
	website := fs.String("website", "", "覆盖业务域名")
	debug := fs.Bool("debug", false, "打印原始请求/响应")
	insecure := fs.Bool("insecure", false, "忽略 TLS 证书校验")
	fs.Parse(args)

	client := neumooc.NewClient(*website, *debug, *insecure)
	cfg := neumooc.DefaultCheckinConfig()
	cfg.Interval = *interval
	cfg.Once = *once
	cfg.MaxRounds = *maxRounds
	cfg.CourseID = *courseID
	cfg.Longitude = *longitude
	cfg.Latitude = *latitude
	cfg.Address = *address
	cfg.QRBypassSignType = *qrSignType
	cfg.IncludeTeacher = *includeTeacher
	cfg.AnyStatus = *anyStatus
	cfg.DryRun = *dryRun
	cfg.MaxAttempts = *maxAttempts
	cfg.Quiet = *quiet
	cfg.PageSize = *pageSize
	if *termID != "" {
		cfg.TermID = *termID
	}

	bot := neumooc.NewAutoCheckinBot(client, cfg)
	if err := bot.Run(); err != nil {
		fmt.Fprintf(os.Stderr, "错误：%v\n", err)
		os.Exit(1)
	}
}

func cmdProfile(args []string) {
	fs := flag.NewFlagSet("profile", flag.ExitOnError)
	website := fs.String("website", "", "覆盖业务域名")
	debug := fs.Bool("debug", false, "debug")
	insecure := fs.Bool("insecure", false, "insecure")
	fs.Parse(args)
	client := neumooc.NewClient(*website, *debug, *insecure)
	data, err := client.GetProfile()
	if err != nil {
		fmt.Fprintf(os.Stderr, "错误：%v\n", err)
		os.Exit(1)
	}
	printJSON(data)
}

func cmdRefresh(args []string) {
	fs := flag.NewFlagSet("refresh", flag.ExitOnError)
	website := fs.String("website", "", "覆盖业务域名")
	debug := fs.Bool("debug", false, "debug")
	insecure := fs.Bool("insecure", false, "insecure")
	fs.Parse(args)
	client := neumooc.NewClient(*website, *debug, *insecure)
	if _, err := client.RefreshAccessToken(); err != nil {
		fmt.Fprintf(os.Stderr, "错误：%v\n", err)
		os.Exit(1)
	}
	fmt.Println("[OK] 令牌刷新成功（AUTH-05）")
	printSession(client)
}

func cmdCall(args []string) {
	fs := flag.NewFlagSet("call", flag.ExitOnError)
	paramsRaw := fs.String("params", "", "查询参数 JSON")
	bodyRaw := fs.String("body", "", "请求体 JSON")
	website := fs.String("website", "", "覆盖业务域名")
	debug := fs.Bool("debug", false, "debug")
	insecure := fs.Bool("insecure", false, "insecure")
	fs.Parse(args)
	if fs.NArg() < 2 {
		fmt.Fprintln(os.Stderr, "用法：neumooc call METHOD PATH [--params ...] [--body ...]")
		os.Exit(1)
	}
	method := strings.ToUpper(fs.Arg(0))
	path := fs.Arg(1)

	client := neumooc.NewClient(*website, *debug, *insecure)
	var params map[string]string
	if *paramsRaw != "" {
		var m map[string]interface{}
		if json.Unmarshal([]byte(*paramsRaw), &m) == nil {
			params = map[string]string{}
			for k, v := range m {
				params[k] = fmt.Sprint(v)
			}
		}
	}
	var body interface{}
	if *bodyRaw != "" {
		_ = json.Unmarshal([]byte(*bodyRaw), &body)
	}
	data, err := client.Call(method, path, params, body)
	if err != nil {
		fmt.Fprintf(os.Stderr, "错误：%v\n", err)
		os.Exit(1)
	}
	printJSON(data)
}

func printSession(c *neumooc.Client) {
	fmt.Printf("  业务域名 : %s\n", c.Base)
	fmt.Printf("  租户 ID  : %s\n", c.TenantID)
	fmt.Printf("  用户 ID  : %v\n", c.UserID)
	fmt.Printf("  访问令牌 : %s\n", mask(c.AccessToken))
	fmt.Printf("  刷新令牌 : %s\n", mask(c.RefreshToken))
}

func mask(s string) string {
	if s == "" {
		return "<空>"
	}
	if len(s) <= 4 {
		return s + "****"
	}
	if len(s) <= 16 {
		return s[:4] + "****"
	}
	return s[:10] + "..." + s[len(s)-6:]
}

func printJSON(v interface{}) {
	b, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		fmt.Println(v)
		return
	}
	fmt.Println(string(b))
}
