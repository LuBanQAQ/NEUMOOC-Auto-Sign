# 东软智慧教育 Go SDK / CLI

Python 版 `neumooc_login.py` / `neumooc_checkin.py` 的 Go 移植：纯标准库、无第三方依赖，
编译后单文件可执行，方便挂到 Linux 服务器。

- `client.go`：`neumooc.Client`（登录、刷新令牌、通用请求、401 自动刷新/凭据重登、会话与凭据持久化）
- `checkin.go`：`neumooc.AutoCheckinBot`（自动签到，直接发包，二维码考勤直签 `refreshSeed="0"`）
- `cmd/neumooc/main.go`：命令行入口

## 构建

```bash
cd gosdk
go build ./cmd/neumooc
# 或直接运行
go run ./cmd/neumooc --help
```

交叉编译（Linux 服务器上跑）：

```bash
GOOS=linux GOARCH=amd64 go build -o neumooc-linux ./cmd/neumooc
```

## 用法

```bash
# 登录（--save-credentials 保存密码，令牌失效自动重登）
./neumooc login -u 学号 -p 密码 -t 租户ID --save-credentials

# 演练：只看会提交什么
./neumooc auto-checkin --once --dry-run

# 正式直接发包签到（每 30 秒扫一轮，Ctrl+C 停）
./neumooc auto-checkin

# 只跑一轮
./neumooc auto-checkin --once

# 校验令牌 / 手动刷新
./neumooc profile
./neumooc refresh

# 调用任意接口
./neumooc call GET /web-api/system/notify-target/get-unread-count
./neumooc call POST /web-api/teachmanager/teach-course-attendance-detail/getAppStuAttendancePage --body '{"studentId":1,"termId":1}'
```

常用 `auto-checkin` 参数与 Python 版一致：

| 参数 | 作用 |
| --- | --- |
| `--interval 15` | 轮询间隔秒（默认 30，最小 5） |
| `--once` | 只扫一轮 |
| `--dry-run` | 只打印提交体，不真签 |
| `--qr-sign-type 0` | 二维码考勤改按普通签到(type=0)提交 |
| `--longitude 121.5 --latitude 38.9 --address 教学楼A` | 覆盖默认学校坐标 |
| `--include-teacher` | 教师考勤也签 |
| `--max-rounds 120 --quiet` | 安静模式 + 限定轮数 |
| `--website 域名 --debug` | 覆盖域名 / 打印请求 |

## SDK 调用示例

```go
package main

import (
    "fmt"
    "neumooc"
)

func main() {
    c := neumooc.NewClient("", false, false) // 自动读取 neumooc_token.json
    if _, err := c.LoginWithPassword("学号", "密码", "租户ID"); err != nil {
        panic(err)
    }
    terms, _ := c.GetTermOptions()
    fmt.Println(terms)

    bot := neumooc.NewAutoCheckinBot(c, neumooc.DefaultCheckinConfig())
    _ = bot.Run()
}
```

## 说明

- 令牌保存到 `neumooc_token.json`，凭据保存到 `neumooc_credentials.json`（明文，Linux 建议 `chmod 600`）。
- 二维码考勤直签提交体与 Python 版一致：`type=1`、`refreshSeed="0"`、默认学校坐标
  （`121.614682 / 38.914003 / 大连东软信息学院`），不扫描二维码、不调用 ATT-04 校验。
- 登录仍是明文 `username/password`；若服务端要求 `isPasswordEncrypt` + AES，需自行补充加密逻辑。
